Please copy 'vs workspeace' folder in local disk E:

E:\