package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class Admin extends objectclass{
	JFrame Adminfr=new JFrame();
	JLabel bg=new JLabel(new ImageIcon("E:\\vs workspace\\class system\\abg.png"));
	JTextField usnf=new JTextField();
	JPasswordField passf=new JPasswordField();
	JButton loginbtn=new JButton(new ImageIcon("E:\\\\vs workspace\\\\class system\\\\loginbtn.png"));
	int ex=5;
	Checkastudent cas=new Checkastudent();
	Checkallstudent caas=new Checkallstudent();
	Takenote takn=new Takenote();
	Registerstudent reg=new Registerstudent();
	Deleteastudent del=new Deleteastudent();
	Accountcontrol acc=new Accountcontrol();
	public Admin() {
		// TODO Auto-generated constructor stub
		JFrame.setDefaultLookAndFeelDecorated(true);
		cas.ckstbtn.setVisible(true);
		caas.casbtn.setVisible(true);
		takn.taknobtn.setVisible(true);
		reg.regbtn.setVisible(true);
		del.delbtn.setVisible(true);
		acc.accbtn.setVisible(true);
		loginbtn.setBounds(250, 340, 115, 45);
		usnf.setBounds(180, 155, 250, 40);
		usnf.setFont(new Font("arial", Font.TRUETYPE_FONT, 18));
		passf.setBounds(180, 274, 250, 40);
		Adminfr.setSize(500, 440);
		Adminfr.setVisible(true);
		Adminfr.setResizable(false);
		bg.add(usnf);bg.add(passf);bg.add(loginbtn);
		Adminfr.add(bg);
		loginbtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent ae) {
				// TODO Auto-generated method stub
					Adminfr.dispose();
					appfr.setSize(615, 735);
					appfr.setVisible(true);
					appfr.setResizable(false);
					appfr.add(appbg);
				
				
			}
		});
		
	}
	
	
}