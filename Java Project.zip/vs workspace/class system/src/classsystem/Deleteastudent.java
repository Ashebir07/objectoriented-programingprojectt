package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Deleteastudent extends objectclass{
	JButton delbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\del.png"));
	public Deleteastudent() {
		// TODO Auto-generated constructor stub
		JFrame delfr=new JFrame();
		JLabel debg=new JLabel(new ImageIcon("E:\\vs workspace\\class system\\delbg.png"));
		JButton debtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\debtn.png"));
		JTextField def=new JTextField();
		def.setBounds(90, 134, 230, 30);
		debtn.setBounds(150, 220, 105, 40);
		delfr.setSize(420, 340);
		delbtn.setBounds(400, 150, 155, 55);
		appbg.add(delbtn);
		delbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				delfr.setVisible(true);
				delfr.add(debg);debg.add(def);debg.add(debtn);
			}
		});
		debtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}

}
