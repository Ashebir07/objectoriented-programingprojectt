package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Checkallstudent extends objectclass{
	JButton casbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\checallst.png"));
	JTable cekallta=new JTable(60,8);
	JFrame jtbg=new  JFrame();
	JScrollPane jsp=new JScrollPane(cekallta);
	public Checkallstudent() {
		// TODO Auto-generated constructor stub
		
		casbtn.setBounds(50, 150, 155, 55);
		appbg.add(casbtn);
		cekallta.setBackground(Color.black.darker());
		cekallta.setForeground(Color.white.brighter());
		cekallta.setFont(new Font("arial", Font.BOLD, 13));
		cekallta.setValueAt("name", 0, 0);
		cekallta.setValueAt("sex", 0, 1);
		cekallta.setValueAt("id", 0, 2);
		cekallta.setValueAt("section", 0, 3);
		cekallta.setValueAt("group", 0, 4);
		cekallta.setValueAt("department", 0, 5);
		cekallta.setValueAt("type", 0, 6);
		cekallta.setValueAt("year", 0, 7);
		jtbg.setSize(1000, 750);
		casbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				
			}
		});
	}
}
