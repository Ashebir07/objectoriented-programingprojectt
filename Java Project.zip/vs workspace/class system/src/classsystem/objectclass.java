package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class objectclass {
	static JFrame appfr = new JFrame();
	static JLabel appbg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\bg.png"));
	static JButton menubtn = new JButton(new ImageIcon("E:\\\\vs workspace\\\\class system\\\\menu.png"));

}
