package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Accountcontrol extends objectclass {
	JButton accbtn = new JButton(new ImageIcon("E:\\vs workspace\\class system\\acc.png"));
	String getusn = null, getop = null;

	public Accountcontrol() {

		JButton upbtn = new JButton(new ImageIcon("E:\\vs workspace\\class system\\upbtn.png"));
		upbtn.setBounds(220, 410, 105, 40);
		JFrame accfr = new JFrame();
		JLabel accbg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\accbg.png"));
		JTextField ouf = new JTextField();
		JTextField nuf = new JTextField();
		JTextField rnuf = new JTextField();
		JPasswordField opf = new JPasswordField();
		JPasswordField npf = new JPasswordField();
		JPasswordField rnpf = new JPasswordField();
		ouf.setBounds(175, 128, 190, 30);
		opf.setBounds(175, 176, 190, 30);
		nuf.setBounds(175, 224, 190, 30);
		npf.setBounds(175, 272, 190, 30);
		rnuf.setBounds(175, 323, 190, 30);
		rnpf.setBounds(175, 371, 190, 30);
		accfr.setSize(400, 500);
		accbtn.setBounds(400, 260, 155, 55);
		appbg.add(accbtn);
		accbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				ouf.setText("");
				opf.setText("");
				nuf.setText("");
				npf.setText("");
				rnuf.setText("");
				rnpf.setText("");
				accfr.setVisible(true);
				accfr.add(accbg);
				accbg.add(ouf);
				accbg.add(opf);
				accbg.add(nuf);
				accbg.add(npf);
				accbg.add(rnuf);
				accbg.add(rnpf);
				accbg.add(upbtn);
				
			}
		});
		upbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String e1, e2, e3, e4, e5, e6;
				e1 = ouf.getText();
				e2 = new String(opf.getPassword());
				e3 = nuf.getText();
				e4 = new String(npf.getPassword());
				e5 = rnuf.getText();
				e6 = new String(rnpf.getPassword());
				if (getusn.equals(e1) && getop.equals(e2)) {
					if (e3.equals(e5)) {
						if (e4.equals(e6)) {
							
						} else {
							JOptionPane.showMessageDialog(accfr, "new password didn't match", "alert",
									JOptionPane.WARNING_MESSAGE);
						}

					} else {
						JOptionPane.showMessageDialog(accfr, "new username didn't match", "alert",
								JOptionPane.WARNING_MESSAGE);

					}

				} else {
					JOptionPane.showMessageDialog(accfr, "you got wrong old username or password", "alert",
							JOptionPane.WARNING_MESSAGE);
				}

			}
		});

	}

}
