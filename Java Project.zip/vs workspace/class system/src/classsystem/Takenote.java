package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

public class Takenote extends objectclass {
	JButton taknobtn = new JButton(new ImageIcon("E:\\vs workspace\\class system\\takenote.png"));
	String gette = null;
	JFrame delfr = new JFrame();
	JFrame sfr = new JFrame();
	JFrame opfr = new JFrame();
	JFrame taknotefr = new JFrame();
	JLabel bg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\notbg.png"));
	JTextArea notf = new JTextArea("  ");
	JMenu menu;
	JMenuItem ex, sa, op, dele, edi, dela, ne, alno;
	JMenuBar bar = new JMenuBar();
	JTextField saf = new JTextField();
	JTextField opf = new JTextField();
	JTextField delf = new JTextField();
	JLabel opbg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\opnot.png"));
	JLabel sabg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\opnot.png"));
	JLabel debg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\opnot.png"));
	JButton debtn = new JButton("delete");
	JButton opbtn = new JButton("open");
	JButton sabtn = new JButton("save");

	public Takenote() {
		// TODO Auto-generated constructor stub
		taknobtn.setBounds(50, 260, 155, 55);
		appbg.add(taknobtn);
		//////////

		menu = new JMenu("menu");
		ex = new JMenuItem("exit                                   .");
		sa = new JMenuItem("save                                .");
		op = new JMenuItem("open                                .");
		dele = new JMenuItem("delete                              .");
		edi = new JMenuItem("edit                                  .");
		dela = new JMenuItem("delete all                         .");
		ne = new JMenuItem("new note                        .");
		alno = new JMenuItem("check all notes              .");
		menu.add(ne);
		menu.add(op);
		menu.add(sa);
		menu.add(alno);
		menu.add(edi);
		menu.add(dele);
		menu.add(dela);
		menu.add(ex);
		bar.add(menu);

		taknobtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				notf.setText("\n  ");
				notf.setEditable(true);
				notf.setForeground(Color.BLACK);

				notf.setBounds(40, 40, 400, 510);
				notf.setFont(new Font("arial", Font.PLAIN, 18));
				notf.setBorder(new BevelBorder(0, Color.BLACK, Color.black, Color.black, Color.black));
				notf.setBackground(Color.white.brighter());
				taknotefr.setSize(470, 660);
				taknotefr.setVisible(true);
				bg.add(notf);
				taknotefr.add(bg);
				taknotefr.setJMenuBar(bar);
			}
		});
		ne.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				notf.setText("\n  ");
				notf.setEditable(true);
				notf.setForeground(Color.BLACK);
				sa.setVisible(true);

			}
		});

		op.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				opbtn.setBorder(new BevelBorder(0, Color.red, Color.RED, Color.red, Color.red));
				opbtn.setBounds(140, 110, 90, 40);
				opbtn.setFont(new Font("arial", Font.BOLD, 22));
				opbtn.setBackground(Color.blue);
				opbtn.setForeground(Color.white);
				opfr.setSize(400, 200);
				opfr.setVisible(true);
				opf.setText("");
				opf.setBounds(90, 60, 200, 40);
				opf.setBorder(new BevelBorder(0, Color.black, Color.black, Color.black, Color.black));
				opbg.add(opf);
				opfr.add(opbg);
				opbg.add(opbtn);

			}
		});
		opbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				

			}
		});

		sa.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				sabtn.setBorder(new BevelBorder(0, Color.red, Color.RED, Color.red, Color.red));
				sabtn.setBounds(140, 110, 90, 40);
				sabtn.setFont(new Font("arial", Font.BOLD, 22));
				sabtn.setBackground(Color.blue);
				sabtn.setForeground(Color.white);
				sfr.setSize(400, 200);
				sfr.setVisible(true);
				saf.setText("");
				saf.setBounds(90, 60, 200, 40);
				saf.setBorder(new BevelBorder(0, Color.black, Color.black, Color.black, Color.black));
				sabg.add(saf);
				sabg.add(sabtn);
				sfr.add(sabg);

			}
		});
		sabtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		alno.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		edi.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				notf.setEditable(true);
				notf.setForeground(Color.black);
				sa.setVisible(true);
			}
		});
		dele.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				notf.setText("\n  ");
				notf.setEditable(true);
				notf.setForeground(Color.BLACK);
				debtn.setBorder(new BevelBorder(0, Color.red, Color.RED, Color.red, Color.red));
				debtn.setBounds(140, 110, 90, 40);
				debtn.setFont(new Font("arial", Font.BOLD, 22));
				debtn.setBackground(Color.blue);
				debtn.setForeground(Color.white);
				delfr.setSize(400, 200);
				delfr.setVisible(true);
				delf.setText("");
				delf.setBounds(90, 60, 200, 40);
				delf.setBorder(new BevelBorder(0, Color.black, Color.black, Color.black, Color.black));
				debg.add(delf);
				delfr.add(debg);
				debg.add(debtn);

			}
		});
		debtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});

		ex.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				taknotefr.dispose();
			}
		});

		dela.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				

			}
		});
	}

}
