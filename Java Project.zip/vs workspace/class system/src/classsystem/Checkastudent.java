package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Checkastudent extends objectclass{
	JButton ckstbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\checkstfd.png"));
	JFrame cekstfr=new JFrame();
	JTextField cekf=new JTextField();
	JLabel cbg=new JLabel(new ImageIcon("E:\\vs workspace\\class system\\checkstfdbg.png"));
	String gett=null;
	JButton cekbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\cebg.png"));

	public Checkastudent() {
		// TODO Auto-generated constructor stub
		
		ckstbtn.setBounds(50, 40, 155, 55);
		cekstfr.setSize(500, 440);
		appbg.add(ckstbtn);cekstfr.setResizable(false);
		
		ckstbtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
		        cekf.setBounds(95, 180, 300, 40);
		        cekbtn.setBounds(180, 300, 125, 45);
		        cbg.add(cekf);cekf.setText("");
				cekstfr.setVisible(true);
		        cbg.add(cekbtn);
				cekstfr.add(cbg);
				
				
				
			}
		});
		cekbtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JTable casttb=new JTable(5,8);

				casttb.setBackground(Color.black.darker());
				casttb.setForeground(Color.white.brighter());
				casttb.setFont(new Font("arial", Font.BOLD, 13));
				casttb.setValueAt("name", 0, 0);
				casttb.setValueAt("sex", 0, 1);
				casttb.setValueAt("id", 0, 2);
				casttb.setValueAt("section", 0, 3);
				casttb.setValueAt("group", 0, 4);
				casttb.setValueAt("department", 0, 5);
				casttb.setValueAt("type", 0, 6);
				casttb.setValueAt("year", 0, 7);
				gett=cekf.getText();
				
			}
		});
	}

}
