package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Home implements ActionListener{
	JButton adminbtn,sercbtn,exitbtn;
	JFrame homefr=new JFrame("astu class system");
	public Home() {
		// TODO Auto-generated constructor stub
		adminbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\admin.png"));
		adminbtn.setBounds(150, 100, 125, 44);
		sercbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\search.png"));
		sercbtn.setBounds(350, 100, 125, 44);
		exitbtn=new JButton(new ImageIcon("E:\\vs workspace\\class system\\exitbtn.png"));
		exitbtn.setBounds(250, 600, 123, 45);
		JLabel bg=new JLabel(new ImageIcon("E:\\vs workspace\\class system\\bg.png"));
		homefr.setSize(620, 740);
		homefr.setResizable(false);
		bg.add(adminbtn);bg.add(sercbtn);bg.add(exitbtn);
		homefr.add(bg);
		homefr.setVisible(true);
		exitbtn.addActionListener(this);
		adminbtn.addActionListener(this);
		sercbtn.addActionListener(this);
		
	}
	public static void main(String[] args) {
	    new Home();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==exitbtn) {
			System.exit(0);
			
		}
		if(e.getSource()==adminbtn) {
			new Admin();
			homefr.dispose();
		}
		
		if(e.getSource()==sercbtn) {
			new Searchstudent();
		}
		
	}
	
}