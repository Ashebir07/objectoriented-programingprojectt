package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Registerstudent extends objectclass {
	JButton regbtn = new JButton(new ImageIcon("E:\\vs workspace\\class system\\reg.png"));

	public Registerstudent() {
		// TODO Auto-generated constructor stub
		JFrame regfr = new JFrame();
		regfr.setSize(415, 630);
		JLabel regbg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\regbg.png"));
		JTextField naf = new JTextField();
		JTextField idf = new JTextField();
		JTextField sef = new JTextField();
		JTextField grf = new JTextField();
		naf.setBounds(155, 80, 230, 30);
		idf.setBounds(155, 185, 230, 30);
		sef.setBounds(155, 235, 230, 30);
		grf.setBounds(155, 285, 230, 30);

		JButton regibtn = new JButton(new ImageIcon("E:\\vs workspace\\class system\\reibtn.png"));
		String[] type = { "Add", "Regular" };
		String[] sex = { "M", "F" };
		String[] dep = { "CSE", "ECE", "EPCE" };
		String[] yr = { "II", "I", "III", "IV", "V" };
		JComboBox year = new JComboBox(yr);
		JComboBox dept = new JComboBox(dep);
		JComboBox ty = new JComboBox(type);
		JComboBox sx = new JComboBox(sex);
		sx.setBounds(155, 130, 230, 30);
		ty.setBounds(155, 405, 230, 30);
		year.setBounds(155, 455, 230, 30);
		dept.setBounds(155, 345, 230, 30);
		regbtn.setBounds(400, 40, 155, 55);
		regibtn.setBounds(210, 510, 120, 45);
		appbg.add(regbtn);
		regbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				regfr.setVisible(true);
				regbg.add(year);
				regbg.add(dept);
				regbg.add(ty);
				regbg.add(sx);
				regbg.add(sef);
				regbg.add(grf);
				regbg.add(idf);
				regbg.add(regibtn);
				regbg.add(naf);
				regfr.add(regbg);

			}
		});
		regibtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});

	}

}
