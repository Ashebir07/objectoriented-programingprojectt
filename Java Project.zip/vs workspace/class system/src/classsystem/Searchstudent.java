package classsystem;
/*
    Name                     ID            Section   Group
1, Ashegire Selamu        UGR/16810/11       10       19
2, Ashebir Wondemeneh     UGR/16809/11       10       19
3, Yeabsera Lisanework    UGR/17788/11       10       20
4, Milkias Solomon        UGR/17407/11       10       20
5, Ephrem Fikadu          UGR/17050/11       10       19
*/
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

class Searchstudent extends objectclass {
	String gtf = null;
	JFrame sefr = new JFrame("student search");
	JLabel bg = new JLabel(new ImageIcon("E:\\vs workspace\\class system\\searchbg.png"));
	JButton sbtn = new JButton(new ImageIcon("E:\\vs workspace\\class system\\search.png"));
	JTextField sef = new JTextField("            enter id or name here");
	JFrame tafr = new JFrame("searched student");

	public Searchstudent() {
		appfr.dispose();
		// TODO Auto-generated constructor stub
		sefr.setSize(500, 440);
		sefr.setVisible(true);
		sefr.add(bg);
		sefr.setResizable(false);
		sef.setBounds(100, 180, 300, 40);
		sef.setFont(new Font("arial", Font.PLAIN, 18));
		sef.setForeground(Color.GREEN.darker());
		sbtn.setBounds(180, 300, 125, 45);
		sbtn.setBackground(Color.ORANGE.darker());
		bg.add(sef);
		bg.add(sbtn);

		sef.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				sef.setText("");

			}
		});
		sbtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				

			}
		});

	}

}